set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[key_filter_by_org]
@caseind  bigint = 1
As Begin
 If (@caseind = organization_Guid) Select Distinct key_Guid from Table_1
End
