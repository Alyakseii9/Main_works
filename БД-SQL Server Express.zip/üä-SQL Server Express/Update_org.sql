SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[Table_2]
 @id bigint,
 @name_organization nvarchar(50)
AS 
UPDATE [SSS].[dbo].[Table_2]
   SET [id] = @id
      ,[name_organization] = @name_organization
 WHERE id = @id