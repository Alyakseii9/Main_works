set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[Update_key]
 @id bigint,
 @key_Guid nvarchar(50),
 @date_start datetime(50),
 @date_finish datetime(50),
 @organization_Guid bigint(50),
 @info_for_bllock nvarchar(50),
AS 
UPDATE [DB].[dbo].[Table_1]
   SET [id] = @id
      ,[key_Guid] = @key_Guid
      ,[date_start] = @date_start
      ,[date_finish] = @date_finish
      ,[organization_Guid] = @organization_Guid
      ,[info_for_bllock] = @info_for_bllock
 WHERE id_Guid = @Id 