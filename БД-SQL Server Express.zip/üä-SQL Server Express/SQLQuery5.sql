set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

ALTER Procedure [dbo].[Drop_name_org]
@id int
AS
 Begin
 Delete from Table_2 where  id = @id
 End
 

