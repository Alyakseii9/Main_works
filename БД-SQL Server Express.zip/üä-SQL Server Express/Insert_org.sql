set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[Insert_org]
 @id nvarchar(50),
 @name_organization nvarchar(50)
AS Begin
 
 INSERT INTO [Table_2]
           ([id]
           ,[name_organization]
            )
     VALUES
           (@id,@name_organization)
End
