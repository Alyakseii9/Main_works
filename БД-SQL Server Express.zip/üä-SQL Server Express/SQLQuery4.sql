set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

ALTER Procedure [dbo].[Get_organizations]
@name_organization nvarchar(50)
As
If (@name_organization != '' 
  begin
   Select name_organization   From Table_2   
  End

