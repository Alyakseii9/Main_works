set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[Insert_key]
 @id bigint,
 @key_Guid nvarchar(50),
 @date_start datetime,
 @date_finish datetime,
 @organization_Guid bigint,
 @info_for_bllock nvarchar(50)
AS Begin
 
 INSERT INTO [Table_1]
           ([id]
           ,[key_Guid]
           ,[date_start]
           ,[date_finish]
           ,[organization_Guid]
           ,[info_for_bllock])
     VALUES
           (@id,@key_Guid,@date_start,@date_finish,@organization_Guid
            ,@info_for_bllock)
End
